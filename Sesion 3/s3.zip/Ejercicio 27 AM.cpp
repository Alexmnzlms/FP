/*

*/

#include <iostream>
#include <cmath>

using namespace std;

int main(){
	
	int edad, estado_civil;
	double producto_interior_bruto;
	bool es_primo, es_hombre;
	
	// Se utiliza un int para almacenar la edad y el estado civil( ya que puede contener cuatro valores diferentes)
	// Se utiliza un double para el producto interior bruto
	// Se utiliza un bool para la cualidad de ser primo y la de ser hombre (porque si no es hombre es mujer)
}
